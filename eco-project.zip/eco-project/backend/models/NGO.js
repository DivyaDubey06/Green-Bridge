import mongoose from "mongoose";

const ngoSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
  contact: String,
  requiredSkills: [String],
});

export default mongoose.model("NGO", ngoSchema);
