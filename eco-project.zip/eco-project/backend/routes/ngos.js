// routes/ngos.js
import express from "express";
import { pool } from "../config/db.js";

const router = express.Router();

// GET all NGOs
router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM ngos ORDER BY id DESC");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST register NGO
router.post("/", async (req, res) => {
  try {
    const { name, contact, requirement } = req.body;
    const [result] = await pool.query(
      "INSERT INTO ngos (name, contact, requirement) VALUES (?, ?, ?)",
      [name, contact, requirement]
    );
    res.status(201).json({ id: result.insertId, name, contact, requirement });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
