// routes/volunteers.js
import express from "express";
import { pool } from "../config/db.js";

const router = express.Router();

// GET all volunteers
router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM volunteers ORDER BY id DESC");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST register volunteer
router.post("/", async (req, res) => {
  try {
    const { name, phone, address, skill } = req.body;
    const [result] = await pool.query(
      "INSERT INTO volunteers (name, phone, address, skill) VALUES (?, ?, ?, ?)",
      [name, phone, address, skill]
    );
    res.status(201).json({ id: result.insertId, name, phone, address, skill });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
