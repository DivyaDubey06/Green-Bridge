// seed.js -- run with `npm run seed`
import dotenv from "dotenv";
dotenv.config();
import { pool } from "./config/db.js";

const run = async () => {
  try {
    // Create tables if not exist
    await pool.query(`
      CREATE TABLE IF NOT EXISTS volunteers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        phone VARCHAR(20),
        address VARCHAR(255),
        skill VARCHAR(50)
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS ngos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        contact VARCHAR(100),
        requirement VARCHAR(255)
      );
    `);

    // Clear existing demo rows
    await pool.query("DELETE FROM volunteers");
    await pool.query("DELETE FROM ngos");

    // Insert demo volunteers
    const volunteers = [
      ["Divya Dubey", "9999999999", "Dehradun", "Planting"],
      ["Amit Sharma", "8888888888", "Dehradun", "Cleaning"],
      ["Neha Verma", "7777777777", "Dehradun", "Awareness"],
      ["Rohit Singh", "6666666666", "Dehradun", "Planting"],
      ["Priya Joshi", "5555555555", "Dehradun", "Cleaning"]
    ];
    await pool.query("INSERT INTO volunteers (name, phone, address, skill) VALUES ?", [volunteers]);

    // Insert demo NGOs
    const ngos = [
      ["Green Dehradun", "0123456789", "Planting, Awareness"],
      ["CleanCity", "9876543210", "Cleaning"],
      ["RiverCare", "9112233445", "Cleanup"]
    ];
    await pool.query("INSERT INTO ngos (name, contact, requirement) VALUES ?", [ngos]);

    console.log("Seed data added!");
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};

run();
