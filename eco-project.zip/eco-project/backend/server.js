import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mysql from "mysql2";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
const db = mysql.createConnection({
host: "localhost",
user: "root",         
password: "DivyaDubey2006",        
database: "eco_project"
});

db.connect((err) => {
if (err) {
console.error("❌ MySQL Connection Failed:", err);
return;
}
console.log("✅ MySQL Connected Successfully");
});

app.get("/api/ngos", (req, res) => {
db.query("SELECT * FROM ngos", (err, results) => {
if (err) return res.status(500).json({ error: err });
res.json(results);
});
});
app.get("/api/volunteers", (req, res) => {
db.query("SELECT * FROM volunteers", (err, results) => {
if (err) return res.status(500).json({ error: err });
res.json(results);
});
});
app.post("/api/register-volunteer", (req, res) => {
const { name, phone, address, skill } = req.body;
```
const sql = "INSERT INTO volunteers (name, phone, address, skill) VALUES (?, ?, ?, ?)";

db.query(sql, [name, phone, address, skill], (err, result) => {
    if (err) return res.status(500).json({ error: err });

    res.json({ message: "Volunteer Registered Successfully!" });
});
```
});
app.get("/api/events", (req, res) => {
db.query("SELECT * FROM events", (err, results) => {
if (err) return res.status(500).json({ error: err });
res.json(results);
});
});
app.get("/api/health", (req, res) => res.json({ status: "ok" }));
const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
