// Demo Data
let ngosData = [
    {id:1, name:"GreenEarth NGO", address:"Dehradun", phone:"9999999999", description:"Planting trees", registered:[{name:"Amit"}], otherRegistered:[{name:"Rina"}]},
    {id:2, name:"CleanRiver NGO", address:"Dehradun", phone:"8888888888", description:"River Cleaning", registered:[], otherRegistered:[]}
];

let volunteersData = [
    {name:"Divya", phone:"9999999999", address:"Dehradun", skill:"Planting"},
    {name:"Amit", phone:"8888888888", address:"Dehradun", skill:"Cleaning"}
];

let eventsData = [
    {id:1, title:"Tree Plantation", location:"Dehradun Park", date:"2025-12-10", description:"Planting trees for environment"},
    {id:2, title:"River Cleanup", location:"Ganga", date:"2025-12-15", description:"Cleaning the river"},
];

let donations = [];

// Tabs
function showTab(tabId){
    document.querySelectorAll('.tab').forEach(t=>t.style.display='none');
    document.getElementById(tabId).style.display='block';
}

// Load NGOs
function loadNGOs(){
    const container=document.getElementById("ngo-list");
    container.innerHTML="";
    ngosData.forEach(ngo=>{
        container.innerHTML+=`
        <div class="card">
            <h3>${ngo.name}</h3>
            <p>${ngo.address}</p>
            <p>${ngo.phone}</p>
            <p>${ngo.description}</p>
            <button onclick="applyNGO(${ngo.id})">Apply to Volunteer</button>
            <button onclick="registerOther(${ngo.id})">Other Registration</button>
            <h4>Registered Volunteers:</h4>
            <ul>${ngo.registered.map(n=>`<li>${n.name}</li>`).join('')}</ul>
            <h4>Other Registrations:</h4>
            <ul>${ngo.otherRegistered?.map(n=>`<li>${n.name}</li>`).join('')||''}</ul>
        </div>`;
    });
}

// Apply to volunteer
function applyNGO(id){
    const name=prompt("Enter your Name to volunteer");
    if(!name) return;
    const ngo=ngosData.find(n=>n.id===id);
    ngo.registered.push({name});
    loadNGOs();
}

// Other Registration
function registerOther(id){
    const name=prompt("Enter your Name for other registration");
    if(!name) return;
    const ngo=ngosData.find(n=>n.id===id);
    if(!ngo.otherRegistered) ngo.otherRegistered=[];
    ngo.otherRegistered.push({name});
    loadNGOs();
}

// Load Volunteers
function loadVolunteers(){
    const container=document.getElementById("volunteer-list");
    container.innerHTML="";
    volunteersData.forEach(v=>{
        container.innerHTML+=`
        <div class="card">
            <h3>${v.name}</h3>
            <p>Phone: ${v.phone}</p>
            <p>Address: ${v.address}</p>
            <p>Skill: ${v.skill}</p>
        </div>`;
    });
}

// Volunteer registration
document.addEventListener("DOMContentLoaded",()=>{
    showTab("home");
    loadNGOs();
    loadVolunteers();
    loadEvents();

    const form=document.getElementById("registerForm");
    if(form){
        form.addEventListener("submit",(e)=>{
            e.preventDefault();
            const volunteer={
                name:form.name.value,
                phone:form.phone.value,
                address:form.address.value,
                skill:form.skill.value
            };
            volunteersData.push(volunteer);
            alert("Volunteer Registered Successfully!");
            form.reset();
            loadVolunteers();
        });
    }

    const donationForm=document.getElementById("donationForm");
    if(donationForm){
        donationForm.addEventListener("submit",(e)=>{
            e.preventDefault();
            const donation={
                name:donationForm.name.value,
                amount:donationForm.amount.value,
                photo:donationForm.photo.files[0]?.name || "No Image"
            };
            donations.push(donation);
            alert("Donation Recorded!");
            donationForm.reset();
            loadDonations();
        });
    }
});

// Load Events
function loadEvents(){
    const container=document.getElementById("event-list");
    container.innerHTML="";
    eventsData.forEach(e=>{
        container.innerHTML+=`
        <div class="card">
            <h3>${e.title}</h3>
            <p>Location: ${e.location}</p>
            <p>Date: ${e.date}</p>
            <p>${e.description}</p>
            <button onclick="applyEvent(${e.id})">Apply for Event</button>
        </div>`;
    });
}

// Apply for Event
function applyEvent(id){
    const name=prompt("Enter your Name to apply for this event");
    if(!name) return;
    const event=eventsData.find(ev=>ev.id===id);
    if(!event.applied) event.applied=[];
    event.applied.push({name});
    loadEvents();
}

// Load Donations
function loadDonations(){
    const container=document.getElementById("donation-list");
    container.innerHTML="<h4>Donations:</h4>";
    donations.forEach(d=>{
        container.innerHTML+=`
        <div class="card">
            <p>Name: ${d.name}</p>
            <p>Amount: ${d.amount}</p>
            <p>Photo: ${d.photo}</p>
        </div>`;
    });
}
